const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production'
    ? { rejectUnauthorized: false }   // Railway uses self-signed certs
    : false,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000
});

// ── query helper — auto-returns rows ────────────────────────────────────
const query = async (text, params) => {
  const start = Date.now();
  try {
    const res = await pool.query(text, params);
    const ms  = Date.now() - start;
    if (ms > 1000) console.warn(`Slow query (${ms}ms):`, text.substring(0, 80));
    return res;
  } catch (err) {
    console.error('DB query error:', err.message, '|', text.substring(0, 80));
    throw err;
  }
};

// ── transaction helper ───────────────────────────────────────────────────
const withTransaction = async (fn) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
};

// ── connection test ──────────────────────────────────────────────────────
const dbTest = async () => {
  const res = await query('SELECT NOW() as now');
  return res.rows[0];
};

module.exports = { pool, query, withTransaction, dbTest };

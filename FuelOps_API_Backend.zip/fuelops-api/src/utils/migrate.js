require('dotenv').config();
const { pool } = require('../utils/db');
const fs = require('fs');
const path = require('path');

async function migrate() {
  const client = await pool.connect();
  try {
    console.log('Running FuelOps migrations...');

    // Users table (not in main schema — add here)
    await client.query(`
      CREATE TABLE IF NOT EXISTS users (
        id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        email         VARCHAR(200) NOT NULL UNIQUE,
        password_hash VARCHAR(100) NOT NULL,
        full_name     VARCHAR(100) NOT NULL,
        active        BOOLEAN DEFAULT TRUE,
        last_login    TIMESTAMPTZ,
        created_at    TIMESTAMPTZ DEFAULT NOW()
      );
    `);
    console.log('✅ users table ready');

    // Make user_roles reference users table
    await client.query(`
      CREATE TABLE IF NOT EXISTS user_roles (
        user_id      VARCHAR(100) NOT NULL,
        role         VARCHAR(30) NOT NULL
                     CHECK (role IN ('CEO','VP_OPS','FUEL_MANAGER','DISPATCHER','PILOT','DATA_ADMIN','READ_ONLY')),
        base_icao    CHAR(4),
        aircraft_type VARCHAR(20),
        granted_at   TIMESTAMPTZ DEFAULT NOW(),
        granted_by   VARCHAR(100),
        PRIMARY KEY (user_id, role)
      );
    `);
    console.log('✅ user_roles table ready');

    // Run the main schema file
    const schemaPath = path.join(__dirname, '..','..','..','FuelOps_Database_Schema.sql');
    if (fs.existsSync(schemaPath)) {
      const sql = fs.readFileSync(schemaPath, 'utf8');
      // Split on semicolons but skip empty and comment-only statements
      const statements = sql.split(';')
        .map(s => s.trim())
        .filter(s => s.length > 10 && !s.startsWith('--'));

      let ok = 0, skip = 0;
      for (const stmt of statements) {
        try {
          await client.query(stmt);
          ok++;
        } catch (e) {
          if (e.code === '42P07' || e.code === '42710') { skip++; }  // already exists
          else console.warn('  Skipped:', e.message.substring(0, 80));
        }
      }
      console.log(`✅ Schema: ${ok} statements run, ${skip} already existed`);
    } else {
      console.log('ℹ️  Schema file not found — place FuelOps_Database_Schema.sql in project root');
    }

    // Create default admin user
    const bcrypt = require('bcryptjs');
    const hash   = await bcrypt.hash('FuelOps2025!', 12);
    await client.query(`
      INSERT INTO users (email, password_hash, full_name)
      VALUES ('admin@fuelops.in', $1, 'System Administrator')
      ON CONFLICT (email) DO NOTHING
    `, [hash]);
    await client.query(`
      INSERT INTO user_roles (user_id, role)
      SELECT id, 'DATA_ADMIN' FROM users WHERE email='admin@fuelops.in'
      ON CONFLICT DO NOTHING
    `);
    console.log('✅ Default admin created (admin@fuelops.in / FuelOps2025!)');
    console.log('⚠️  CHANGE THE DEFAULT PASSWORD IMMEDIATELY AFTER FIRST LOGIN');

    console.log('\n🎉 Migration complete');
  } catch (err) {
    console.error('Migration failed:', err.message);
    process.exit(1);
  } finally {
    client.release();
    await pool.end();
  }
}

migrate();

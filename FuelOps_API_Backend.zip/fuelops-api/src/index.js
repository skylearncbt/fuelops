require('dotenv').config();
const express      = require('express');
const cors         = require('cors');
const helmet       = require('helmet');
const compression  = require('compression');
const rateLimit    = require('express-rate-limit');
const path         = require('path');

const authRoutes      = require('./routes/auth');
const dashboardRoutes = require('./routes/dashboard');
const uploadRoutes    = require('./routes/upload');
const fuelRoutes      = require('./routes/fuel');
const waterRoutes     = require('./routes/water');
const aircraftRoutes  = require('./routes/aircraft');
const pilotRoutes     = require('./routes/pilots');
const { errorHandler } = require('./middleware/error');
const { dbTest }      = require('./utils/db');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Security middleware ──────────────────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));
app.use(compression());

// ── CORS ─────────────────────────────────────────────────────────────────
const allowedOrigins = (process.env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);
app.use(cors({
  origin: (origin, cb) => {
    if (!origin || allowedOrigins.includes(origin) || process.env.NODE_ENV === 'development') {
      return cb(null, true);
    }
    cb(new Error('Not allowed by CORS'));
  },
  credentials: true
}));

// ── Rate limiting ─────────────────────────────────────────────────────────
app.use('/api/', rateLimit({
  windowMs: 15 * 60 * 1000,   // 15 minutes
  max: 300,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests — please wait 15 minutes' }
}));

app.use('/api/auth/', rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  message: { error: 'Too many login attempts' }
}));

// ── Body parsing ──────────────────────────────────────────────────────────
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));

// ── Health check ──────────────────────────────────────────────────────────
app.get('/health', async (req, res) => {
  const db = await dbTest().catch(() => false);
  res.json({
    status: db ? 'ok' : 'degraded',
    db: db ? 'connected' : 'error',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  });
});

// ── API routes ────────────────────────────────────────────────────────────
app.use('/api/auth',      authRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/upload',    uploadRoutes);
app.use('/api/fuel',      fuelRoutes);
app.use('/api/water',     waterRoutes);
app.use('/api/aircraft',  aircraftRoutes);
app.use('/api/pilots',    pilotRoutes);

// ── 404 ───────────────────────────────────────────────────────────────────
app.use((req, res) => res.status(404).json({ error: 'Route not found' }));

// ── Error handler ─────────────────────────────────────────────────────────
app.use(errorHandler);

// ── Start ─────────────────────────────────────────────────────────────────
app.listen(PORT, async () => {
  console.log(`FuelOps API running on port ${PORT} [${process.env.NODE_ENV}]`);
  const db = await dbTest().catch(e => { console.error('DB connection failed:', e.message); return false; });
  if (db) console.log('Database connected successfully');
});

module.exports = app;

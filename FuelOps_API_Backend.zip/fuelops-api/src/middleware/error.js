const errorHandler = (err, req, res, next) => {
  console.error(`[${new Date().toISOString()}] ${req.method} ${req.path}:`, err.message);

  if (err.code === '23505') {   // Postgres unique violation
    return res.status(409).json({ error: 'Duplicate record', detail: err.detail });
  }
  if (err.code === '23503') {   // Foreign key violation
    return res.status(400).json({ error: 'Referenced record not found', detail: err.detail });
  }
  if (err.code === '23514') {   // Check constraint violation
    return res.status(400).json({ error: 'Value out of allowed range', detail: err.detail });
  }
  if (err.name === 'MulterError') {
    return res.status(400).json({ error: 'File upload error', detail: err.message });
  }
  if (err.message === 'Not allowed by CORS') {
    return res.status(403).json({ error: 'CORS: origin not allowed' });
  }

  const status = err.status || err.statusCode || 500;
  res.status(status).json({
    error: status === 500 ? 'Internal server error' : err.message,
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
};

// ── Async wrapper — catches promise rejections ────────────────────────────
const asyncHandler = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

module.exports = { errorHandler, asyncHandler };

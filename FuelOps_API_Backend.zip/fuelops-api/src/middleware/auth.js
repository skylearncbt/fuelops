const jwt = require('jsonwebtoken');

// ── Role hierarchy ────────────────────────────────────────────────────────
const ROLE_LEVELS = {
  CEO:          7,
  VP_OPS:       6,
  FUEL_MANAGER: 5,
  DISPATCHER:   4,
  PILOT:        3,
  DATA_ADMIN:   2,
  READ_ONLY:    1
};

// ── Verify token ──────────────────────────────────────────────────────────
const authenticate = (req, res, next) => {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'No token provided' });
  }
  const token = header.split(' ')[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    const msg = err.name === 'TokenExpiredError' ? 'Token expired' : 'Invalid token';
    return res.status(401).json({ error: msg });
  }
};

// ── Require minimum role ──────────────────────────────────────────────────
const requireRole = (...roles) => (req, res, next) => {
  if (!req.user) return res.status(401).json({ error: 'Not authenticated' });
  const userLevel = ROLE_LEVELS[req.user.role] || 0;
  const minLevel  = Math.max(...roles.map(r => ROLE_LEVELS[r] || 0));
  if (userLevel < minLevel) {
    return res.status(403).json({
      error: 'Insufficient permissions',
      required: roles,
      yourRole: req.user.role
    });
  }
  next();
};

// ── Pilot can only see own data unless higher role ────────────────────────
const pilotSelf = (req, res, next) => {
  const { role, sub } = req.user;
  if (role === 'PILOT' && req.params.pilotId && req.params.pilotId !== sub) {
    return res.status(403).json({ error: 'Pilots can only view their own data' });
  }
  next();
};

module.exports = { authenticate, requireRole, pilotSelf, ROLE_LEVELS };

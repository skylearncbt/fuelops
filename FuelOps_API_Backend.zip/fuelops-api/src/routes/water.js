const express = require('express');
const { query } = require('../utils/db');
const { authenticate, requireRole } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/error');

// ── WATER ROUTES ──────────────────────────────────────────────────────────
const waterRouter = express.Router();
waterRouter.use(authenticate);

waterRouter.get('/', asyncHandler(async (req, res) => {
  const { dep, from, to, page = 1, limit = 50 } = req.query;
  const params = []; const conds = ['1=1'];
  if (dep)  { params.push(dep.toUpperCase()); conds.push(`wu.dep_icao=$${params.length}`); }
  if (from) { params.push(from); conds.push(`wu.uplift_datetime::date>=$${params.length}`); }
  if (to)   { params.push(to);   conds.push(`wu.uplift_datetime::date<=$${params.length}`); }
  params.push(parseInt(limit), (parseInt(page)-1)*parseInt(limit));

  const { rows } = await query(`
    SELECT wu.*, f.flight_number, f.flight_date,
           wv.name AS vendor_name, wc.cert_number, wc.expiry_date
    FROM water_uplifts wu
    JOIN flights f ON f.id = wu.flight_id
    LEFT JOIN water_vendors wv ON wv.id = wu.vendor_id
    LEFT JOIN water_certificates wc ON wc.id = wu.certificate_id
    WHERE ${conds.join(' AND ')}
    ORDER BY wu.uplift_datetime DESC
    LIMIT $${params.length-1} OFFSET $${params.length}
  `, params);

  res.json({ data: rows, page: parseInt(page), limit: parseInt(limit) });
}));

waterRouter.post('/', requireRole('FUEL_MANAGER','DATA_ADMIN','DISPATCHER'), asyncHandler(async (req, res) => {
  const { flight_id, dep_icao, vendor_id, certificate_id,
          uplift_volume_l, tank_capacity_l, drainage_l, remarks } = req.body;
  if (!flight_id || !uplift_volume_l) {
    return res.status(400).json({ error: 'flight_id and uplift_volume_l required' });
  }
  const { rows } = await query(`
    INSERT INTO water_uplifts
      (flight_id, uplift_datetime, dep_icao, vendor_id, certificate_id,
       uplift_volume_l, tank_capacity_l, drainage_l, remarks, entered_by)
    VALUES ($1, NOW(), $2, $3, $4, $5, $6, $7, $8, $9)
    RETURNING *
  `, [flight_id, dep_icao, vendor_id||null, certificate_id||null,
      uplift_volume_l, tank_capacity_l||200, drainage_l||0, remarks||null, req.user.email]);
  res.status(201).json(rows[0]);
}));

waterRouter.get('/compliance', asyncHandler(async (req, res) => {
  const { rows } = await query('SELECT * FROM vw_water_compliance ORDER BY days_to_expiry NULLS LAST');
  res.json(rows);
}));

// ── AIRCRAFT ROUTES ───────────────────────────────────────────────────────
const aircraftRouter = express.Router();
aircraftRouter.use(authenticate);

aircraftRouter.get('/', asyncHandler(async (req, res) => {
  const { rows } = await query(
    'SELECT * FROM aircraft WHERE active=true ORDER BY registration'
  );
  res.json(rows);
}));

aircraftRouter.get('/:registration', asyncHandler(async (req, res) => {
  const { rows } = await query(
    'SELECT * FROM aircraft WHERE registration=$1',
    [req.params.registration.toUpperCase()]
  );
  if (!rows.length) return res.status(404).json({ error: 'Not found' });
  res.json(rows[0]);
}));

aircraftRouter.post('/', requireRole('DATA_ADMIN','CEO'), asyncHandler(async (req, res) => {
  const { registration, aircraft_type, msn, delivery_date,
          base_icao, oem_burn_kg_hr } = req.body;
  if (!registration || !aircraft_type) {
    return res.status(400).json({ error: 'registration and aircraft_type required' });
  }
  const { rows } = await query(`
    INSERT INTO aircraft (registration, aircraft_type, msn, delivery_date, base_icao, oem_burn_kg_hr)
    VALUES ($1, $2, $3, $4, $5, $6) RETURNING *
  `, [registration.toUpperCase(), aircraft_type, msn||null,
      delivery_date||null, base_icao||null, oem_burn_kg_hr||null]);
  res.status(201).json(rows[0]);
}));

aircraftRouter.get('/:registration/performance', asyncHandler(async (req, res) => {
  const { rows } = await query('SELECT * FROM vw_tail_performance WHERE registration=$1',
    [req.params.registration.toUpperCase()]);
  if (!rows.length) return res.status(404).json({ error: 'No performance data found' });
  res.json(rows[0]);
}));

aircraftRouter.get('/fleet/performance', asyncHandler(async (req, res) => {
  const { rows } = await query('SELECT * FROM vw_tail_performance ORDER BY avg_burn_kg_hr');
  res.json(rows);
}));

// ── PILOT ROUTES ──────────────────────────────────────────────────────────
const pilotRouter = express.Router();
pilotRouter.use(authenticate);

pilotRouter.get('/', requireRole('FUEL_MANAGER','VP_OPS','CEO','DATA_ADMIN'), asyncHandler(async (req, res) => {
  const { base } = req.query;
  const params = []; const conds = ['active=true'];
  if (base) { params.push(base.toUpperCase()); conds.push(`base_icao=$${params.length}`); }
  const { rows } = await query(
    `SELECT id, employee_id, full_name, rank, base_icao, type_rating
     FROM pilots WHERE ${conds.join(' AND ')} ORDER BY full_name`,
    params
  );
  res.json(rows);
}));

pilotRouter.get('/performance', requireRole('FUEL_MANAGER','VP_OPS','CEO'), asyncHandler(async (req, res) => {
  const { base } = req.query;
  let sql = 'SELECT * FROM vw_pilot_performance';
  const params = [];
  if (base) { params.push(base.toUpperCase()); sql += ' WHERE base_icao=$1'; }
  sql += ' ORDER BY avg_variance_pct DESC NULLS LAST';
  const { rows } = await query(sql, params);
  res.json(rows);
}));

pilotRouter.get('/bases', asyncHandler(async (req, res) => {
  const { rows } = await query(`
    SELECT * FROM (
      SELECT base_icao,
        COUNT(*)                                        AS pilots,
        ROUND(AVG(avg_burn_kg_hr)::numeric,2)           AS avg_burn,
        ROUND(AVG(avg_variance_pct)::numeric,2)         AS avg_variance,
        ROUND(AVG(total_extra_fuel_kg)::numeric,0)      AS avg_extra_kg
      FROM vw_pilot_performance
      WHERE base_icao IS NOT NULL
      GROUP BY base_icao
    ) t ORDER BY avg_burn DESC
  `);
  res.json(rows);
}));

const waterRouter2 = waterRouter;
module.exports = waterRouter2;
module.exports.waterRouter = waterRouter;
module.exports.aircraftRouter = aircraftRouter;
module.exports.pilotRouter = pilotRouter;

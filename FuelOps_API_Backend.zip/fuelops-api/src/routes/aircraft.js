const { aircraftRouter } = require('./water');
module.exports = aircraftRouter;

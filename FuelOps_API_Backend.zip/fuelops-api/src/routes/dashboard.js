const express = require('express');
const { query } = require('../utils/db');
const { authenticate, requireRole } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/error');

const router = express.Router();
router.use(authenticate);

// ── Helper: date filter ───────────────────────────────────────────────────
function periodClause(period, alias = 'f') {
  const p = period || 'ytd';
  const t = alias ? alias + '.' : '';
  if (p === 'mtd')  return `${t}flight_date >= date_trunc('month', CURRENT_DATE)`;
  if (p === 'qtd')  return `${t}flight_date >= date_trunc('quarter', CURRENT_DATE)`;
  if (p === 'ytd')  return `${t}flight_date >= date_trunc('year', CURRENT_DATE)`;
  if (p === 'l30')  return `${t}flight_date >= CURRENT_DATE - 30`;
  if (p === 'l90')  return `${t}flight_date >= CURRENT_DATE - 90`;
  return `${t}flight_date >= date_trunc('year', CURRENT_DATE)`;
}

// ── GET /api/dashboard/executive ─────────────────────────────────────────
router.get('/executive', requireRole('CEO','VP_OPS','FUEL_MANAGER'), asyncHandler(async (req, res) => {
  const { period, base } = req.query;
  const whereDate = periodClause(period);
  const baseFilter = base && base !== 'all' ? `AND p.base_icao = '${base}'` : '';

  const [kpi, monthly, byType, topAirports] = await Promise.all([
    // KPIs
    query(`
      SELECT
        ROUND(SUM(fu.total_cost)::numeric/10000000, 2)          AS fuel_cost_cr,
        ROUND(AVG(fob.burn_kg_per_hr)::numeric, 0)              AS avg_burn_kg_hr,
        ROUND(AVG(fu.variance_pct * 100)::numeric, 2)           AS avg_variance_pct,
        COUNT(CASE WHEN fu.extra_fuel_kg > 0 THEN 1 END)        AS extra_fuel_events,
        SUM(fu.extra_fuel_kg)                                   AS total_extra_kg,
        ROUND(SUM(e.co2_kg)::numeric/1000, 1)                   AS co2_tonnes
      FROM flights f
      JOIN fuel_uplifts fu ON fu.flight_id = f.id
      LEFT JOIN fob_records fob ON fob.flight_id = f.id
      LEFT JOIN emissions_records e ON e.flight_id = f.id
      LEFT JOIN pilots p ON p.id = f.commander_id
      WHERE ${whereDate} ${baseFilter}
    `),
    // Monthly trend
    query(`
      SELECT
        TO_CHAR(f.flight_date,'Mon YYYY')  AS month,
        DATE_TRUNC('month',f.flight_date)  AS month_sort,
        ROUND(SUM(fu.total_cost)::numeric/10000000,2) AS cost_cr,
        ROUND(AVG(fob.burn_kg_per_hr)::numeric,0)     AS avg_burn
      FROM flights f
      JOIN fuel_uplifts fu ON fu.flight_id = f.id
      LEFT JOIN fob_records fob ON fob.flight_id = f.id
      WHERE ${whereDate}
      GROUP BY 1,2 ORDER BY 2
    `),
    // By aircraft type
    query(`
      SELECT
        a.aircraft_type,
        ROUND(SUM(fu.total_cost)::numeric/10000000,2) AS cost_cr,
        ROUND(AVG(fob.burn_kg_per_hr)::numeric,0)     AS avg_burn,
        COUNT(f.id)                                   AS sectors
      FROM flights f
      JOIN aircraft a ON a.id = f.aircraft_id
      JOIN fuel_uplifts fu ON fu.flight_id = f.id
      LEFT JOIN fob_records fob ON fob.flight_id = f.id
      WHERE ${whereDate}
      GROUP BY 1 ORDER BY 2 DESC
    `),
    // Top airports
    query(`
      SELECT
        fu.dep_icao                                       AS airport,
        ROUND(SUM(fu.uplift_kg)::numeric/1000, 1)        AS uplift_mt,
        ROUND(AVG(fu.price_per_kg)::numeric, 2)          AS avg_price,
        ROUND(SUM(fu.total_cost)::numeric/10000000, 2)   AS cost_cr
      FROM fuel_uplifts fu
      JOIN flights f ON f.id = fu.flight_id
      WHERE ${whereDate}
      GROUP BY 1 ORDER BY 4 DESC LIMIT 10
    `)
  ]);

  res.json({
    kpi:         kpi.rows[0],
    monthly:     monthly.rows,
    byType:      byType.rows,
    topAirports: topAirports.rows
  });
}));

// ── GET /api/dashboard/tail/:registration ────────────────────────────────
router.get('/tail/:registration', requireRole('FUEL_MANAGER','VP_OPS','CEO'), asyncHandler(async (req, res) => {
  const { registration } = req.params;
  const { period } = req.query;
  const whereDate = periodClause(period);

  const [info, monthly, vsFleet, routes] = await Promise.all([
    // Aircraft info + performance
    query(`
      SELECT
        a.registration, a.aircraft_type, a.base_icao,
        a.oem_burn_kg_hr,
        ROUND(AVG(fob.burn_kg_per_hr)::numeric,2)      AS actual_burn,
        ROUND(SUM(fob.block_time_hr)::numeric,1)       AS total_hrs,
        COUNT(f.id)                                    AS sectors,
        COUNT(CASE WHEN fu.extra_fuel_kg > 0 THEN 1 END) AS extra_events
      FROM aircraft a
      LEFT JOIN flights f ON f.aircraft_id = a.id AND ${whereDate}
      LEFT JOIN fob_records fob ON fob.flight_id = f.id
      LEFT JOIN fuel_uplifts fu ON fu.flight_id = f.id
      WHERE a.registration = $1
      GROUP BY a.id
    `, [registration]),
    // Monthly burn trend
    query(`
      SELECT
        TO_CHAR(f.flight_date,'Mon') AS month,
        DATE_TRUNC('month',f.flight_date) AS sort,
        ROUND(AVG(fob.burn_kg_per_hr)::numeric,2) AS burn
      FROM flights f
      JOIN aircraft a ON a.id = f.aircraft_id
      JOIN fob_records fob ON fob.flight_id = f.id
      WHERE a.registration = $1 AND ${whereDate}
      GROUP BY 1,2 ORDER BY 2
    `, [registration]),
    // vs fleet
    query(`
      SELECT
        a.registration,
        ROUND(AVG(fob.burn_kg_per_hr)::numeric,2) AS avg_burn
      FROM aircraft a
      JOIN flights f ON f.aircraft_id = a.id
      JOIN fob_records fob ON fob.flight_id = f.id
      WHERE ${whereDate} AND a.aircraft_type LIKE 'A32%'
      GROUP BY a.registration ORDER BY 2
    `),
    // Route performance
    query(`
      SELECT
        CONCAT(f.dep_icao,'-',f.arr_icao)             AS route,
        COUNT(f.id)                                   AS sectors,
        ROUND(AVG(fob.burn_kg_per_hr)::numeric,2)     AS avg_burn,
        ROUND(AVG(fu.variance_pct*100)::numeric,2)    AS avg_variance
      FROM flights f
      JOIN aircraft a ON a.id = f.aircraft_id
      JOIN fob_records fob ON fob.flight_id = f.id
      JOIN fuel_uplifts fu ON fu.flight_id = f.id
      WHERE a.registration = $1 AND ${whereDate}
      GROUP BY 1 ORDER BY 2 DESC LIMIT 10
    `, [registration])
  ]);

  if (!info.rows.length) return res.status(404).json({ error: 'Aircraft not found' });

  res.json({
    info:    info.rows[0],
    monthly: monthly.rows,
    vsFleet: vsFleet.rows,
    routes:  routes.rows
  });
}));

// ── GET /api/dashboard/pilot/:pilotId ────────────────────────────────────
router.get('/pilot/:pilotId', asyncHandler(async (req, res) => {
  const { role, sub } = req.user;
  const { pilotId } = req.params;

  // Pilots can only see their own data
  if (role === 'PILOT' && pilotId !== sub) {
    return res.status(403).json({ error: 'Pilots can only view their own performance' });
  }

  const { period } = req.query;
  const whereDate  = periodClause(period);

  const [info, sectors, vsFleet, extraCodes] = await Promise.all([
    query(`
      SELECT
        p.employee_id, p.full_name, p.base_icao, p.rank,
        COUNT(f.id)                                        AS sectors,
        ROUND(AVG(fob.burn_kg_per_hr)::numeric,2)          AS avg_burn,
        ROUND(AVG(fu.variance_pct*100)::numeric,2)         AS avg_variance_pct,
        COUNT(CASE WHEN fu.extra_fuel_kg > 0 THEN 1 END)   AS extra_requests,
        ROUND(AVG(NULLIF(fu.extra_fuel_kg,0))::numeric,0)  AS avg_extra_kg
      FROM pilots p
      LEFT JOIN flights f ON f.commander_id = p.id AND ${whereDate}
      LEFT JOIN fob_records fob ON fob.flight_id = f.id
      LEFT JOIN fuel_uplifts fu ON fu.flight_id = f.id
      WHERE p.id = $1
      GROUP BY p.id
    `, [pilotId]),
    query(`
      SELECT
        f.flight_date, f.flight_number,
        CONCAT(f.dep_icao,'-',f.arr_icao) AS route,
        a.registration,
        fu.planned_uplift_kg,
        fu.uplift_kg,
        ROUND(fu.variance_pct*100::numeric,2)     AS variance_pct,
        fu.extra_fuel_kg,
        fu.primary_extra_code
      FROM flights f
      JOIN fuel_uplifts fu ON fu.flight_id = f.id
      JOIN aircraft a ON a.id = f.aircraft_id
      WHERE f.commander_id = $1 AND ${whereDate}
      ORDER BY f.flight_date DESC LIMIT 30
    `, [pilotId]),
    // vs fleet
    query(`
      SELECT
        p.id, p.full_name,
        ROUND(AVG(fob.burn_kg_per_hr)::numeric,2)        AS avg_burn,
        ROUND(AVG(fu.variance_pct*100)::numeric,2)       AS avg_variance
      FROM pilots p
      JOIN flights f ON f.commander_id = p.id
      JOIN fob_records fob ON fob.flight_id = f.id
      JOIN fuel_uplifts fu ON fu.flight_id = f.id
      WHERE ${whereDate}
      GROUP BY p.id, p.full_name ORDER BY 3
    `),
    query(`
      SELECT
        fu.primary_extra_code AS code,
        ec.category,
        COUNT(*) AS count,
        AVG(fu.extra_fuel_kg)::int AS avg_extra_kg
      FROM fuel_uplifts fu
      JOIN flights f ON f.id = fu.flight_id
      JOIN extra_fuel_codes ec ON ec.code = fu.primary_extra_code
      WHERE f.commander_id = $1 AND fu.extra_fuel_kg > 0 AND ${whereDate}
      GROUP BY 1,2 ORDER BY 3 DESC
    `, [pilotId])
  ]);

  if (!info.rows.length) return res.status(404).json({ error: 'Pilot not found' });

  res.json({
    info:       info.rows[0],
    sectors:    sectors.rows,
    vsFleet:    vsFleet.rows,
    extraCodes: extraCodes.rows
  });
}));

// ── GET /api/dashboard/water ──────────────────────────────────────────────
router.get('/water', asyncHandler(async (req, res) => {
  const { period } = req.query;
  const whereDate  = periodClause(period, 'wu');

  const [kpi, byRoute, byAirport, compliance] = await Promise.all([
    query(`
      SELECT
        ROUND(SUM(wu.uplift_volume_l)::numeric/1000,2) AS total_kl,
        ROUND(AVG(wu.uplift_volume_l)::numeric,1)      AS avg_per_ta,
        COUNT(CASE WHEN NOT wu.quality_check_passed THEN 1 END) AS quality_flags
      FROM water_uplifts wu WHERE ${whereDate}
    `),
    query(`
      SELECT
        CONCAT(f.dep_icao,'-',f.arr_icao)          AS route,
        ROUND(AVG(wu.uplift_volume_l)::numeric,1)  AS avg_litres,
        COUNT(wu.id)                               AS uplifts
      FROM water_uplifts wu
      JOIN flights f ON f.id = wu.flight_id
      WHERE ${whereDate}
      GROUP BY 1 ORDER BY 2 DESC LIMIT 12
    `),
    query(`
      SELECT
        wu.dep_icao                                AS airport,
        ROUND(SUM(wu.uplift_volume_l)::numeric,0)  AS total_litres,
        ROUND(AVG(wu.uplift_volume_l)::numeric,1)  AS avg_litres,
        COUNT(wu.id)                               AS uplifts
      FROM water_uplifts wu WHERE ${whereDate}
      GROUP BY 1 ORDER BY 2 DESC
    `),
    // Vendor cert compliance
    query(`SELECT * FROM vw_water_compliance ORDER BY days_to_expiry NULLS LAST`)
  ]);

  res.json({
    kpi:        kpi.rows[0],
    byRoute:    byRoute.rows,
    byAirport:  byAirport.rows,
    compliance: compliance.rows
  });
}));

// ── GET /api/dashboard/extra-fuel-codes ──────────────────────────────────
router.get('/extra-fuel-codes', asyncHandler(async (req, res) => {
  const { period } = req.query;
  const whereDate  = periodClause(period);

  const { rows } = await query(`
    SELECT
      fu.primary_extra_code                           AS code,
      ec.category,
      ec.description,
      COUNT(*)                                        AS count,
      ROUND(AVG(fu.extra_fuel_kg)::numeric,0)         AS avg_extra_kg,
      SUM(fu.extra_fuel_kg)::int                      AS total_extra_kg,
      (SELECT dep_icao FROM fuel_uplifts fu2
       JOIN flights f2 ON f2.id = fu2.flight_id
       WHERE fu2.primary_extra_code = fu.primary_extra_code
         AND ${periodClause(period, 'f2')}
       GROUP BY dep_icao ORDER BY COUNT(*) DESC LIMIT 1) AS top_airport
    FROM fuel_uplifts fu
    JOIN flights f ON f.id = fu.flight_id
    JOIN extra_fuel_codes ec ON ec.code = fu.primary_extra_code
    WHERE fu.extra_fuel_kg > 0 AND ${whereDate}
    GROUP BY 1,2,3 ORDER BY 4 DESC
  `);

  res.json({ codes: rows });
}));

// ── GET /api/dashboard/tankering ─────────────────────────────────────────
router.get('/tankering', requireRole('FUEL_MANAGER','VP_OPS','CEO'), asyncHandler(async (req, res) => {
  const { period } = req.query;
  const whereDate  = periodClause(period, 'td');

  const [summary, byRoute] = await Promise.all([
    query(`
      SELECT
        COUNT(*) FILTER (WHERE recommendation='TANKER')    AS opportunities,
        COUNT(*) FILTER (WHERE actioned=true)              AS actioned,
        ROUND(SUM(actual_saving)::numeric/100000,2)        AS saving_lakhs,
        ROUND(SUM(CASE WHEN recommendation='TANKER' AND NOT actioned
              THEN net_saving END)::numeric/100000,2)      AS foregone_lakhs
      FROM tankering_decisions td WHERE ${whereDate}
    `),
    query(`
      SELECT
        CONCAT(origin_icao,'-',dest_icao) AS route,
        COUNT(*) FILTER (WHERE recommendation='TANKER') AS opportunities,
        ROUND(AVG(price_diff_kg)::numeric,2)           AS avg_diff,
        ROUND(SUM(actual_saving)::numeric/100000,2)    AS saving_lakhs,
        COUNT(*) FILTER (WHERE actioned)               AS actioned
      FROM tankering_decisions td WHERE ${whereDate}
      GROUP BY 1 ORDER BY 4 DESC NULLS LAST LIMIT 12
    `)
  ]);

  res.json({ summary: summary.rows[0], byRoute: byRoute.rows });
}));

// ── GET /api/dashboard/fob ────────────────────────────────────────────────
router.get('/fob', requireRole('FUEL_MANAGER','VP_OPS','CEO'), asyncHandler(async (req, res) => {
  const { period } = req.query;
  const whereDate  = periodClause(period);

  const [kpi, highEvents, byRoute] = await Promise.all([
    query(`
      SELECT
        ROUND(AVG(fob.fob_on_arrival)::numeric,0)         AS avg_fob_arrival,
        ROUND(AVG(fob.excess_fob_kg)::numeric,0)          AS avg_excess,
        COUNT(*) FILTER (WHERE fob.excess_fob_kg > 200)   AS high_fob_count,
        ROUND(SUM(fob.excess_fob_kg * fu.price_per_kg)
              ::numeric/100000,2)                         AS value_excess_lakhs
      FROM fob_records fob
      JOIN flights f ON f.id = fob.flight_id
      JOIN fuel_uplifts fu ON fu.flight_id = f.id
      WHERE ${whereDate}
    `),
    query(`
      SELECT
        f.flight_number, f.flight_date,
        CONCAT(f.dep_icao,'-',f.arr_icao) AS route,
        a.registration,
        fob.fob_on_arrival,
        fob.planned_fob_arr,
        fob.excess_fob_kg,
        fu.primary_extra_code
      FROM fob_records fob
      JOIN flights f ON f.id = fob.flight_id
      JOIN aircraft a ON a.id = f.aircraft_id
      JOIN fuel_uplifts fu ON fu.flight_id = f.id
      WHERE ${whereDate} AND fob.excess_fob_kg > 200
      ORDER BY fob.excess_fob_kg DESC LIMIT 20
    `),
    query(`
      SELECT
        CONCAT(f.dep_icao,'-',f.arr_icao) AS route,
        ROUND(AVG(fob.excess_fob_kg)::numeric,0) AS avg_excess,
        COUNT(*) FILTER (WHERE fob.excess_fob_kg > 200) AS high_events
      FROM fob_records fob
      JOIN flights f ON f.id = fob.flight_id
      WHERE ${whereDate}
      GROUP BY 1 ORDER BY 2 DESC LIMIT 10
    `)
  ]);

  res.json({ kpi: kpi.rows[0], highEvents: highEvents.rows, byRoute: byRoute.rows });
}));

module.exports = router;

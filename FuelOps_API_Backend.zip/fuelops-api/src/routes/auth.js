const express  = require('express');
const bcrypt   = require('bcryptjs');
const jwt      = require('jsonwebtoken');
const { query } = require('../utils/db');
const { authenticate } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/error');

const router = express.Router();

// ── POST /api/auth/login ──────────────────────────────────────────────────
router.post('/login', asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password required' });
  }

  const { rows } = await query(
    `SELECT u.id, u.email, u.password_hash, u.full_name,
            ur.role, ur.base_icao
     FROM users u
     JOIN user_roles ur ON ur.user_id = u.id
     WHERE u.email = $1 AND u.active = true
     LIMIT 1`,
    [email.toLowerCase().trim()]
  );

  if (!rows.length) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  const user = rows[0];
  const valid = await bcrypt.compare(password, user.password_hash);
  if (!valid) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  // Update last login
  await query('UPDATE users SET last_login = NOW() WHERE id = $1', [user.id]);

  const token = jwt.sign(
    {
      sub:      user.id,
      email:    user.email,
      name:     user.full_name,
      role:     user.role,
      base:     user.base_icao
    },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '8h' }
  );

  res.json({
    token,
    user: {
      id:    user.id,
      email: user.email,
      name:  user.full_name,
      role:  user.role,
      base:  user.base_icao
    }
  });
}));

// ── POST /api/auth/register  (DATA_ADMIN only) ────────────────────────────
router.post('/register', authenticate, asyncHandler(async (req, res) => {
  if (!['CEO','VP_OPS','DATA_ADMIN'].includes(req.user.role)) {
    return res.status(403).json({ error: 'Only admins can create users' });
  }

  const { email, password, full_name, role, base_icao } = req.body;
  if (!email || !password || !full_name || !role) {
    return res.status(400).json({ error: 'email, password, full_name and role are required' });
  }

  const validRoles = ['CEO','VP_OPS','FUEL_MANAGER','DISPATCHER','PILOT','DATA_ADMIN','READ_ONLY'];
  if (!validRoles.includes(role)) {
    return res.status(400).json({ error: 'Invalid role', validRoles });
  }

  const hash = await bcrypt.hash(password, 12);

  const { rows } = await query(
    `INSERT INTO users (email, password_hash, full_name, active)
     VALUES ($1, $2, $3, true)
     RETURNING id, email, full_name`,
    [email.toLowerCase().trim(), hash, full_name]
  );

  await query(
    `INSERT INTO user_roles (user_id, role, base_icao, granted_by)
     VALUES ($1, $2, $3, $4)`,
    [rows[0].id, role, base_icao || null, req.user.sub]
  );

  res.status(201).json({ message: 'User created', user: rows[0] });
}));

// ── GET /api/auth/me ──────────────────────────────────────────────────────
router.get('/me', authenticate, asyncHandler(async (req, res) => {
  const { rows } = await query(
    `SELECT u.id, u.email, u.full_name, u.last_login,
            ur.role, ur.base_icao
     FROM users u
     JOIN user_roles ur ON ur.user_id = u.id
     WHERE u.id = $1`,
    [req.user.sub]
  );
  if (!rows.length) return res.status(404).json({ error: 'User not found' });
  res.json(rows[0]);
}));

// ── POST /api/auth/refresh ────────────────────────────────────────────────
router.post('/refresh', authenticate, (req, res) => {
  const { sub, email, name, role, base } = req.user;
  const token = jwt.sign({ sub, email, name, role, base },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '8h' });
  res.json({ token });
});

module.exports = router;

const express = require('express');
const { query } = require('../utils/db');
const { authenticate, requireRole } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/error');

const router = express.Router();
router.use(authenticate);

// ── GET /api/fuel — list uplifts with filters ────────────────────────────
router.get('/', asyncHandler(async (req, res) => {
  const { dep, tail, from, to, code, page = 1, limit = 50 } = req.query;
  const params = [];
  const conds  = ['1=1'];

  if (dep)  { params.push(dep.toUpperCase());  conds.push(`fu.dep_icao = $${params.length}`); }
  if (tail) { params.push(tail.toUpperCase()); conds.push(`a.registration = $${params.length}`); }
  if (from) { params.push(from);               conds.push(`f.flight_date >= $${params.length}`); }
  if (to)   { params.push(to);                 conds.push(`f.flight_date <= $${params.length}`); }
  if (code) { params.push(code.toUpperCase()); conds.push(`fu.primary_extra_code = $${params.length}`); }

  const offset = (parseInt(page) - 1) * parseInt(limit);
  params.push(parseInt(limit), offset);

  const { rows } = await query(`
    SELECT
      fu.id, f.flight_number, f.flight_date,
      CONCAT(f.dep_icao,'-',f.arr_icao) AS route,
      a.registration, a.aircraft_type,
      p.full_name AS commander,
      fu.uplift_litres, fu.specific_gravity, fu.uplift_kg,
      fu.price_per_kg, fu.total_cost, fu.supplier_id,
      fu.planned_uplift_kg, fu.variance_pct,
      fu.extra_fuel_kg, fu.primary_extra_code,
      fu.invoice_ref, fu.invoice_status,
      fu.is_tankering, fu.data_source
    FROM fuel_uplifts fu
    JOIN flights f ON f.id = fu.flight_id
    LEFT JOIN aircraft a ON a.id = f.aircraft_id
    LEFT JOIN pilots p ON p.id = f.commander_id
    WHERE ${conds.join(' AND ')}
    ORDER BY f.flight_date DESC, f.flight_number
    LIMIT $${params.length - 1} OFFSET $${params.length}
  `, params);

  res.json({ data: rows, page: parseInt(page), limit: parseInt(limit) });
}));

// ── GET /api/fuel/:id ─────────────────────────────────────────────────────
router.get('/:id', asyncHandler(async (req, res) => {
  const { rows } = await query(`
    SELECT fu.*, f.flight_number, f.flight_date, f.dep_icao, f.arr_icao,
           a.registration, p.full_name AS commander
    FROM fuel_uplifts fu
    JOIN flights f ON f.id = fu.flight_id
    LEFT JOIN aircraft a ON a.id = f.aircraft_id
    LEFT JOIN pilots p ON p.id = f.commander_id
    WHERE fu.id = $1
  `, [req.params.id]);
  if (!rows.length) return res.status(404).json({ error: 'Not found' });
  res.json(rows[0]);
}));

// ── POST /api/fuel — manual entry ─────────────────────────────────────────
router.post('/', requireRole('FUEL_MANAGER','DATA_ADMIN'), asyncHandler(async (req, res) => {
  const {
    flight_id, uplift_litres, specific_gravity, price_per_kg,
    supplier_id, invoice_ref, planned_uplift_kg, extra_fuel_kg,
    primary_extra_code, secondary_extra_code, extra_fuel_justification,
    is_tankering, dep_icao
  } = req.body;

  if (!flight_id || !uplift_litres || !specific_gravity || !price_per_kg) {
    return res.status(400).json({ error: 'flight_id, uplift_litres, specific_gravity and price_per_kg are required' });
  }

  const { rows } = await query(`
    INSERT INTO fuel_uplifts
      (flight_id, uplift_datetime, dep_icao, uplift_litres, specific_gravity,
       price_per_kg, supplier_id, invoice_ref, planned_uplift_kg,
       extra_fuel_kg, primary_extra_code, secondary_extra_code,
       extra_fuel_justification, is_tankering, data_source, entered_by)
    VALUES ($1, NOW(), $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, 'MANUAL', $14)
    RETURNING *
  `, [
    flight_id, dep_icao, uplift_litres, specific_gravity, price_per_kg,
    supplier_id || null, invoice_ref || null, planned_uplift_kg || null,
    extra_fuel_kg || 0, primary_extra_code || null, secondary_extra_code || null,
    extra_fuel_justification || null, is_tankering || false, req.user.email
  ]);

  res.status(201).json(rows[0]);
}));

// ── PATCH /api/fuel/:id — update invoice status etc ──────────────────────
router.patch('/:id', requireRole('FUEL_MANAGER','DATA_ADMIN'), asyncHandler(async (req, res) => {
  const allowed = ['invoice_status','invoice_ref','price_per_kg','extra_fuel_justification'];
  const updates = [];
  const params  = [];

  for (const [k, v] of Object.entries(req.body)) {
    if (allowed.includes(k)) {
      params.push(v);
      updates.push(`${k} = $${params.length}`);
    }
  }

  if (!updates.length) return res.status(400).json({ error: 'No valid fields to update' });

  params.push(req.params.id);
  const { rows } = await query(
    `UPDATE fuel_uplifts SET ${updates.join(', ')} WHERE id = $${params.length} RETURNING *`,
    params
  );
  if (!rows.length) return res.status(404).json({ error: 'Not found' });
  res.json(rows[0]);
}));

// ── GET /api/fuel/stats/by-airport ────────────────────────────────────────
router.get('/stats/by-airport', asyncHandler(async (req, res) => {
  const { from, to } = req.query;
  const params = [];
  const conds  = ['1=1'];
  if (from) { params.push(from); conds.push(`f.flight_date >= $${params.length}`); }
  if (to)   { params.push(to);   conds.push(`f.flight_date <= $${params.length}`); }

  const { rows } = await query(`
    SELECT
      fu.dep_icao AS airport,
      COUNT(*)                                         AS uplifts,
      ROUND(SUM(fu.uplift_kg)::numeric/1000,1)         AS uplift_mt,
      ROUND(AVG(fu.price_per_kg)::numeric,2)           AS avg_price,
      ROUND(SUM(fu.total_cost)::numeric/10000000,2)    AS cost_cr,
      ROUND(AVG(fu.variance_pct*100)::numeric,2)       AS avg_variance_pct
    FROM fuel_uplifts fu
    JOIN flights f ON f.id = fu.flight_id
    WHERE ${conds.join(' AND ')}
    GROUP BY 1 ORDER BY 4 DESC
  `, params);

  res.json(rows);
}));

module.exports = router;

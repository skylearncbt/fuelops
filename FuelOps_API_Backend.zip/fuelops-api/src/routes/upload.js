const express  = require('express');
const multer   = require('multer');
const XLSX     = require('xlsx');
const path     = require('path');
const { withTransaction } = require('../utils/db');
const { authenticate, requireRole } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/error');

const router = express.Router();
router.use(authenticate);
router.use(requireRole('FUEL_MANAGER','DATA_ADMIN','VP_OPS'));

// ── Multer config — memory storage (no disk write) ────────────────────────
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: (parseInt(process.env.MAX_FILE_SIZE_MB) || 50) * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (['.xlsx','.xls','.csv'].includes(ext)) return cb(null, true);
    cb(new Error('Only .xlsx, .xls, and .csv files are accepted'));
  }
});

// ── Validation helpers ────────────────────────────────────────────────────
const VALID_CODES = new Set([
  'WX-DEP','WX-DST','WX-ENR','WX-ALT','WX-WIN','WX-ICE',
  'ATC-DLY','ATC-HLD','ATC-RRR','ATC-FLV','ATC-TFC',
  'MX-APU','MX-ENG','MX-FQI','MX-CRZ',
  'PD-CAP','PD-NALT','PD-ISOL','PD-TANK','PD-LONG',
  'OPS-LTE','OPS-WT','OPS-FER','OPS-RVY','OPS-ETOP',
  'NTM-NAV','NTM-APT','NTM-SUA'
]);

const VALID_AC_TYPES = new Set(['A319','A320','A320neo','A321','A321neo']);

function validateFuelRow(row, rowNum) {
  const errors = [];
  if (!row.flight_number)          errors.push('Flight number missing');
  if (!row.flight_date)            errors.push('Date missing');
  if (!row.dep_icao || row.dep_icao.length !== 4) errors.push('Dep ICAO must be 4 chars');
  if (!row.arr_icao || row.arr_icao.length !== 4) errors.push('Arr ICAO must be 4 chars');
  if (!row.tail_number)            errors.push('Tail number missing');
  if (!row.aircraft_type || !VALID_AC_TYPES.has(row.aircraft_type))
    errors.push(`Aircraft type must be one of: ${[...VALID_AC_TYPES].join(', ')}`);
  if (!row.uplift_litres || row.uplift_litres <= 0) errors.push('Uplift litres must be > 0');
  if (!row.specific_gravity || row.specific_gravity < 0.760 || row.specific_gravity > 0.840)
    errors.push('Specific gravity must be 0.760 – 0.840');
  if (!row.price_per_kg || row.price_per_kg <= 0)   errors.push('Price per kg must be > 0');
  if (row.extra_fuel_code && !VALID_CODES.has(row.extra_fuel_code))
    errors.push(`Invalid extra fuel code: ${row.extra_fuel_code}`);
  if (errors.length) return { rowNum, errors };
  return null;
}

// ── Map Excel column headers → field names ────────────────────────────────
function normaliseHeader(h) {
  return (h || '').toString().toLowerCase()
    .replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '');
}

function mapFuelRow(raw) {
  const r = {};
  for (const [k,v] of Object.entries(raw)) r[normaliseHeader(k)] = v;
  return {
    flight_number:    (r.flight_no || r.flight_number || '').toString().trim().toUpperCase(),
    flight_date:      r.date_dd_mm_yyyy || r.date || r.flight_date,
    dep_icao:         (r.dep_icao || '').toString().trim().toUpperCase(),
    arr_icao:         (r.arr_icao || '').toString().trim().toUpperCase(),
    tail_number:      (r.tail_no || r.tail_number || r.aircraft_reg || '').toString().trim().toUpperCase(),
    aircraft_type:    (r.a_c_type || r.aircraft_type || r.ac_type || '').toString().trim().toUpperCase(),
    uplift_litres:    parseFloat(r.uplift_litres) || null,
    specific_gravity: parseFloat(r.specific_gravity || r.sg) || null,
    price_per_kg:     parseFloat(r.price_r_kg || r.price_per_kg) || null,
    supplier_name:    (r.supplier_name || '').toString().trim(),
    planned_uplift_kg:parseFloat(r.planned_uplift_kg) || null,
    extra_fuel_kg:    parseFloat(r.extra_fuel_kg) || 0,
    extra_fuel_code:  (r.extra_fuel_code || '').toString().trim().toUpperCase() || null,
    invoice_ref:      (r.invoice_ref || '').toString().trim() || null,
    captain_id:       (r.capt_id_sign || r.captain_id || '').toString().trim() || null,
  };
}

// ── POST /api/upload/fuel ─────────────────────────────────────────────────
router.post('/fuel', upload.single('file'), asyncHandler(async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

  const wb    = XLSX.read(req.file.buffer, { type: 'buffer', cellDates: true });
  const sheet = wb.Sheets['Fuel Uplift Log'] || wb.Sheets[wb.SheetNames[0]];
  const raw   = XLSX.utils.sheet_to_json(sheet, { defval: null, range: 3 }); // skip first 3 header rows

  if (!raw.length) return res.status(400).json({ error: 'No data rows found in sheet' });

  // Validate all rows first
  const rows   = raw.map(mapFuelRow).filter(r => r.flight_number);
  const errors = rows.map((r, i) => validateFuelRow(r, i + 4)).filter(Boolean);

  if (errors.length > 0 && errors.length === rows.length) {
    return res.status(422).json({
      error: 'All rows failed validation',
      rowErrors: errors.slice(0, 20)
    });
  }

  const validRows  = rows.filter((_, i) => !errors.find(e => e.rowNum === i + 4));
  const inserted   = [];
  const skipped    = [];

  await withTransaction(async (client) => {
    for (const row of validRows) {
      try {
        // Upsert flight
        const fRes = await client.query(`
          INSERT INTO flights (flight_number, flight_date, dep_icao, arr_icao, data_source)
          VALUES ($1, $2, $3, $4, 'EXCEL_UPLOAD')
          ON CONFLICT (flight_number, flight_date, dep_icao) DO UPDATE
            SET arr_icao = EXCLUDED.arr_icao, updated_at = NOW()
          RETURNING id
        `, [row.flight_number, row.flight_date, row.dep_icao, row.arr_icao]);

        const flightId = fRes.rows[0].id;

        // Insert fuel uplift
        await client.query(`
          INSERT INTO fuel_uplifts
            (flight_id, uplift_datetime, dep_icao, uplift_litres, specific_gravity,
             price_per_kg, invoice_ref, planned_uplift_kg, extra_fuel_kg,
             primary_extra_code, data_source, entered_by)
          VALUES ($1, NOW(), $2, $3, $4, $5, $6, $7, $8, $9, 'EXCEL_UPLOAD', $10)
          ON CONFLICT DO NOTHING
        `, [
          flightId, row.dep_icao, row.uplift_litres, row.specific_gravity,
          row.price_per_kg, row.invoice_ref, row.planned_uplift_kg,
          row.extra_fuel_kg, row.extra_fuel_code || null, req.user.email
        ]);

        inserted.push(row.flight_number);
      } catch (err) {
        skipped.push({ flight: row.flight_number, reason: err.message });
      }
    }
  });

  res.json({
    message:        'Upload processed',
    totalRows:      rows.length,
    inserted:       inserted.length,
    skipped:        skipped.length,
    validationErrors: errors.length,
    details: {
      rowErrors:    errors.slice(0, 10),
      skippedRows:  skipped.slice(0, 10)
    }
  });
}));

// ── POST /api/upload/water ────────────────────────────────────────────────
router.post('/water', upload.single('file'), asyncHandler(async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

  const wb    = XLSX.read(req.file.buffer, { type: 'buffer', cellDates: true });
  const sheet = wb.Sheets['Potable Water Uplift'] || wb.Sheets[wb.SheetNames[0]];
  const raw   = XLSX.utils.sheet_to_json(sheet, { defval: null, range: 2 });

  const rows    = raw.filter(r => r['Flight No.']);
  const inserted = [];

  await withTransaction(async (client) => {
    for (const row of rows) {
      const flightNo = (row['Flight No.'] || '').toString().trim().toUpperCase();
      const date     = row['Date'];
      const depIcao  = (row['Dep Station'] || '').toString().trim().toUpperCase();

      const fRes = await client.query(
        `SELECT id FROM flights WHERE flight_number=$1 AND flight_date=$2 AND dep_icao=$3 LIMIT 1`,
        [flightNo, date, depIcao]
      );

      if (!fRes.rows.length) {
        await client.query(`
          INSERT INTO flights (flight_number, flight_date, dep_icao, arr_icao, data_source)
          VALUES ($1, $2, $3, $4, 'EXCEL_UPLOAD') ON CONFLICT DO NOTHING
        `, [flightNo, date, depIcao, (row['Arr Station']||'').toUpperCase()]);
      }

      const flightId = fRes.rows[0]?.id || (await client.query(
        'SELECT id FROM flights WHERE flight_number=$1 AND flight_date=$2 LIMIT 1',
        [flightNo, date]
      )).rows[0]?.id;

      if (!flightId) continue;

      await client.query(`
        INSERT INTO water_uplifts
          (flight_id, uplift_datetime, dep_icao, uplift_volume_l, tank_capacity_l,
           drainage_l, quality_check_passed, remarks, entered_by)
        VALUES ($1, NOW(), $2, $3, $4, $5, $6, $7, $8)
        ON CONFLICT DO NOTHING
      `, [
        flightId, depIcao,
        parseFloat(row['Uplift Volume (L)']) || null,
        parseFloat(row['Tank Capacity (L)']) || 200,
        parseFloat(row['Drainage (L)']) || 0,
        true,
        row['Remarks'] || null,
        req.user.email
      ]);

      inserted.push(flightNo);
    }
  });

  res.json({ message: 'Water upload processed', inserted: inserted.length, total: rows.length });
}));

// ── GET /api/upload/template-info ────────────────────────────────────────
router.get('/template-info', (req, res) => {
  res.json({
    sheets: [
      { name: 'Fuel Uplift Log',     description: 'One row per fuel uplift event',       startRow: 4 },
      { name: 'Extra Fuel Detail',   description: 'Detailed justification for extra fuel', startRow: 3 },
      { name: 'Potable Water Uplift',description: 'Water uplifts per turnaround',         startRow: 3 },
      { name: 'FOB Log',             description: 'Fuel on board at each flight phase',   startRow: 3 },
    ],
    extraFuelCodes: [...VALID_CODES].sort(),
    aircraftTypes:  [...VALID_AC_TYPES]
  });
});

module.exports = router;

# FuelOps API — Airline Fuel & Water Management

Complete REST API backend for the FuelOps dashboard.
Connects to PostgreSQL, handles Excel uploads, serves all dashboard data.

## Quick deploy on Railway (10 minutes)

### Step 1 — Push to GitHub
```bash
cd fuelops-api
git init
git add .
git commit -m "Initial FuelOps API"
# Create a new repo on github.com called fuelops-api (private)
git remote add origin https://github.com/YOURUSERNAME/fuelops-api.git
git branch -M main
git push -u origin main
```

### Step 2 — Deploy on Railway
1. Go to railway.app → New Project → Deploy from GitHub repo
2. Select your `fuelops-api` repository
3. Railway auto-detects Node.js and deploys

### Step 3 — Add PostgreSQL
1. In your Railway project → New → Database → PostgreSQL
2. Railway auto-injects `DATABASE_URL` into your service environment

### Step 4 — Set environment variables
In Railway → your service → Variables, add:
```
JWT_SECRET=your_long_random_secret_here_min_32_chars
JWT_EXPIRES_IN=8h
NODE_ENV=production
ALLOWED_ORIGINS=https://YOURUSERNAME.github.io
```

### Step 5 — Run migration
In Railway → your service → Shell (or use the Railway CLI):
```bash
npm run migrate
```
This creates all tables and a default admin user.

### Step 6 — Get your API URL
Railway provides a URL like: `https://fuelops-api.up.railway.app`
Add this to your dashboard HTML as the API base URL.

## API endpoints

### Authentication
| Method | Path | Role | Description |
|--------|------|------|-------------|
| POST | /api/auth/login | Public | Login → returns JWT |
| POST | /api/auth/register | DATA_ADMIN | Create new user |
| GET | /api/auth/me | Authenticated | Current user info |
| POST | /api/auth/refresh | Authenticated | Refresh JWT |

### Dashboard data
| Method | Path | Min Role | Description |
|--------|------|----------|-------------|
| GET | /api/dashboard/executive | FUEL_MANAGER | Executive KPIs and charts |
| GET | /api/dashboard/tail/:reg | FUEL_MANAGER | Tail-level performance |
| GET | /api/dashboard/pilot/:id | PILOT (own) | Pilot performance |
| GET | /api/dashboard/water | Any auth | Water uplift data |
| GET | /api/dashboard/extra-fuel-codes | Any auth | Code frequency |
| GET | /api/dashboard/tankering | FUEL_MANAGER | Tankering analysis |
| GET | /api/dashboard/fob | FUEL_MANAGER | FOB analysis |

### Excel upload
| Method | Path | Min Role | Description |
|--------|------|----------|-------------|
| POST | /api/upload/fuel | FUEL_MANAGER | Upload fuel uplift Excel |
| POST | /api/upload/water | FUEL_MANAGER | Upload water uplift Excel |
| GET | /api/upload/template-info | Any auth | Template column spec |

### Fuel uplifts
| Method | Path | Description |
|--------|------|-------------|
| GET | /api/fuel | List with filters |
| GET | /api/fuel/:id | Single record |
| POST | /api/fuel | Manual entry |
| PATCH | /api/fuel/:id | Update status |
| GET | /api/fuel/stats/by-airport | Airport summary |

### Water, Aircraft, Pilots
| Method | Path | Description |
|--------|------|-------------|
| GET/POST | /api/water | Water uplifts |
| GET | /api/water/compliance | Cert compliance view |
| GET/POST | /api/aircraft | Aircraft fleet |
| GET | /api/aircraft/fleet/performance | All tail performance |
| GET | /api/pilots | Pilot list |
| GET | /api/pilots/performance | Performance ranking |
| GET | /api/pilots/bases | Base-wise summary |

## Query parameters (most GET endpoints)
- `period` — `mtd`, `qtd`, `ytd`, `l30`, `l90`
- `base` — ICAO code e.g. `VABB`
- `tail` — Registration e.g. `VT-IDA`
- `from` / `to` — Date range `YYYY-MM-DD`
- `page` / `limit` — Pagination

## Default admin credentials (CHANGE IMMEDIATELY)
```
Email:    admin@fuelops.in
Password: FuelOps2025!
```

## Local development
```bash
cp .env.example .env
# Edit .env with your local PostgreSQL credentials
npm install
npm run migrate
npm run dev
```

## Tech stack
- **Runtime:** Node.js 18+
- **Framework:** Express 4
- **Database:** PostgreSQL 15 (via pg)
- **Auth:** JWT (jsonwebtoken) + bcryptjs
- **Excel:** SheetJS (xlsx)
- **Security:** helmet, cors, express-rate-limit
